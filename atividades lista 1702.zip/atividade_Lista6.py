#Permitir entrada apenas se:
#• idade ≥ 18
#• idade ≤ 65
#Usar and.

while True:
    try:
        idade = int(input("Digite a sua idade: "))
        if idade >= 18 and idade <= 65:
            print("Liberado a usar o programa.")
            break
        else:
            print("Valor fora do alcance.")
            break
    except:
        print("Valor invalido")