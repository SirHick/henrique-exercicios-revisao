#Pedir salário.
#Condições:
#• mínimo 1320
#• máximo 50000
#• não aceitar texto
#• repetir até válido

while True:
    try:
        salario = float(input("Digite o seu salario: "))
        if salario >= 1320 and salario <= 50000:
            print("Registrado")
            break
        else:
            print("Fora do alcance")
    except:
        print("Valor invalido")