#Sistema de votação
#Pedir idade.
#Se:
#• idade < 16 → não vota
#• 16–17 → opcional
#• 18–70 → obrigatório
#• 70 → opcional
#Validar entrada numérica.

while True:
    try:
        idade = int(input("Digite a sua idade: "))
        if idade < 16:
            print("Não vota")
            break
        elif idade >= 16 and idade <= 17:
            print("não obrigatório")
            break
        elif idade >= 18 and idade <= 70:
            print("obrigatório")
            break
        elif idade > 70:
            print("opcional")
            break
    except:
        print("Valor inválido")