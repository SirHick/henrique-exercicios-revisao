#Cadastro completo
#Pedir:
#• nome
#• idade
#• salário
#Regras:
#• idade válida
#• salário positivo
#• nome mínimo 3 letras
#Usar:
#• try
#• and
#• while

while True:
    try:
        nome = str(input("Digite o seu nome: "))
        idade = int(input("Digite a sua idade: "))
        salario = float(input("Digite o seu salário: "))
        
        if nome.isalpha() and len(nome) >= 3:
            print("ok")
            
        else:
            print("erro")

        
        if idade >= 0 and idade <= 100:
            print("ok")
            
        else:
            print("erro 2")

        if salario > 0:
            print("ok")
            break
        else:
            print("erro 3")

    except:
        print("Valor Inválido")