#Peça uma nota entre 0 e 10.
#Condições:
#• decimal permitido
#• usar float
#• validar faixa

while True: 
    try: 
        nota = float(input("Digite uma nota: "))
        if nota >= 0 and nota <= 10:
            print("Sucesso na ação")
            break
        else: 
            print("Valor fora do alcance")
    except: 
        print("Valor invalido")