#Peça a idade.
#Condições:
#• entre 0 e 120
#• usar and
#• validar com try

while True: 
    try: 
        idade = int(input("Digite a sua idade: "))
        if idade >= 0 and idade <= 120:
            print("Ok")
            break
        else:
            print("valor fora do alcance") 
    except:
        print("Erro, valor inválido: ")
