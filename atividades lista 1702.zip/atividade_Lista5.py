#Peça um número inteiro e diga se é par ou ímpar.
#Se digitar texto, não quebrar o programa.

while True:
    try: 
        valor = int(input("Digite um valor inteiro: "))
        if valor % 2 == 0:
            print("É par")
            break
        else: 
            print("É impar")
            break
    except:
        print("Valor errado")