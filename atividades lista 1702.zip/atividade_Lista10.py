#Pedir quantidade de peças.
#Regras:
#• inteiro
#• não negativo
#• máximo 1000

while True:
    try:
        qtd_pecas = int(input("Digite a quantidade de peças no estoque: "))
        if qtd_pecas >= 0 and qtd_pecas <= 1000:
            print("Registrado")
            break
        else:
            print("Fora do alcance")
    except:
        print("Valor invalido")