#Simulador de compras
#Pedir preço do produto.
#Regras:
#• deve ser positivo
#• se >100 → aplicar desconto
#• validar com try

while True:
    try:
        nome_Prod = str(input("Digite o nome do produto: "))
        preco = float(input("Digite o preço do produto: "))
        
        if preco > 0:
            print("ok")
            
        else:
            print("erro")

        if preco > 100:
            print("válido para desconto")
            break
        else:
            print("erro 2")
    
    except:
        print("valor inválido")