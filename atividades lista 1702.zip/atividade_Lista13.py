#Média de aluno
#Pedir 3 notas válidas (0–10).
#Calcular média.
#Se alguma nota inválida → pedir novamente.



while True:
    try:
        nota1 = float(input("Digite a nota 1: "))
        nota2 = float(input("Digite a nota 2: "))
        nota3 = float(input("Digite a nota 3: "))

        if  0 <= nota1 <= 10 and 0 <= nota2 <= 10 and 0 <= nota3 <= 10:
                media = (nota1 + nota2 + nota3) / 3
                print("A média é: ", media)
                break
        else:
            print("Notas inválidas. Por favor, digite notas entre 0 e 10.")
    except ValueError: 
        print("Entrada inválida, digite um número válido")