#Peça um número inteiro positivo.
#Regras:
#• não aceitar negativo
#• não aceitar texto
#• repetir até válido

while True: 
    try:
        num = int(input("Digite um numero inteiro: "))
        if num >= 0 and num != int:
            print("Ok")
            break
        else:
            print("valor fora do alcance")
    except: 
        print("Reescreva, valor inválido: ")