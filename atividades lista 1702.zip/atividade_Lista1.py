#Peça um número inteiro.
#Se o usuário digitar texto, peça novamente até acertar.

while True: 
    try: 
        num = int(input("Digite um numero inteiro: "))
        print("Ok")
        break
    except: 
        print("tente novamente, valor indevido: ")