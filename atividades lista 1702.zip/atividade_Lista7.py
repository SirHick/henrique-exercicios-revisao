#Permitir entrada se:
#• idade < 12
#ou
#• idade > 60
#Usar or.

while True:
    try:
        idade = int(input("Digite a sua idade: "))
        if idade < 12 or idade > 60:
            print("Acesso liberado.")
            break
        else: 
            print("Valor fora do alcance.")
    except:
        print("Valor inválido")