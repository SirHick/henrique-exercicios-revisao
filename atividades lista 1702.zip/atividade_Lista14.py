#Mostrar menu:
#1 - Somar
#2 - Subtrair
#3 - Sair
#Validar:
#• só aceitar 1, 2 ou 3
#• não aceitar texto

while True:
    try: 
        escolha = int(input("Digite o número para a ação desejada --- 1. Somar | \n2. Subtrair \nou 3. Sair: "))
        if escolha == 1:
            print("Você entrou na parte de soma")
            break
        elif escolha == 2:
            print("Você está no menu de subtração")
            break
        elif escolha == 3:
            print("Você saiu")
            break
        else:
            print("Erro")
    except:
        print("Valor inválido")