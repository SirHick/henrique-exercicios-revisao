# CALCULADORA
# Pedir dois números e uma operação.
#Regras:
#• validar números
#• evitar divisão por zero


while True:
    try:
        num1 = float(input("Digite um número: "))
        num2 = float(input("Digite um número: "))
        operacao = int(input("Digite qual operação você deseja: 1. SOMA | 2. SUBTRAÇÃO\n 3. MULTIPLICAÇÃO e QUALQUER OUTRO. DIVISÃO - "))

        if operacao == 1:
            soma = num1 + num2
            print("Sua soma é: ", soma)
        elif operacao == 2:
            subtracao = num1 - num2
            print("Sua subtração é: ", subtracao)
        elif operacao == 3:
            multi = num1 * num2
            print("Sua multiplicação é: ", multi)
        else:
            divisao = num1 / num2
            print("Sua divisão é: ", divisao)
        break
    except ValueError:
        print("Valor errado")