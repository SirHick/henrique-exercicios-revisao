#Sistema de caixa eletrônico
#Pedir valor de saque.
#Regras:
#• mínimo 10
#• máximo 1000
#• múltiplo de 10
#• validar entrada
#Dica:
#valor % 10 == 0

while True:
    try:
        pedido = int(input("Digite o valor de saque desejado: "))
        if pedido % 10 == 0 and pedido >= 10  and pedido <= 1000:
            print("válido\n Saque efetuado com sucesso")
            break
        else:
            print("erro")
            
    except:
        print("Valor inválido")