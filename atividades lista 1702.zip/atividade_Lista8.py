#Pedir uma senha numérica de 4 dígitos.
#Condições:
#• deve ser número
#• entre 1000 e 9999

while True:
    try:
        senha = int(input("Digite a sua senha: "))
        if senha > 1000 and senha <=9999:
            print("Acesso Liberado")
            break
        else:
            print("Erro")
    except: 
        print("Valor inválido")