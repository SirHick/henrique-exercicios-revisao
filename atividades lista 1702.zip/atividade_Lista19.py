#Tabuada segura
#Pedir número para tabuada.
#Regras:
#• entre 1 e 10
#• validar entrada

while True:
    try:
        num = int(input("Digite um número para a tabuada: "))
        if num >= 1 and num <= 10:
            print("ok")
            print(num * 1, num * 2, num *3, num *4, num*5, num*6, num*7, num*8, num*9, num*10)
            break
        else:
            print("erro")
    except:
        print("Valor Inválido")


