#Usuário correto: admin
#Senha correta: 1234
#Permitir 3 tentativas.
#Usar:
#• if
#• and
#• contador

for i in range (3):
    usuario = str(input("Digite o seu usuário: "))
    senha = int(input("Digite a sua senha: "))
    if usuario == "admin" and senha == 1234:
        print("ACESSO LIBERADO")
        break
    else:
        print("Acesso Negado")
if i == 2:
    print("Bloqueado!")